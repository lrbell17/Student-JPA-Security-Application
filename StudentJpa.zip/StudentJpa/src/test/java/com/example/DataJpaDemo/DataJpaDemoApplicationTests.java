package com.example.DataJpaDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataJpaDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
